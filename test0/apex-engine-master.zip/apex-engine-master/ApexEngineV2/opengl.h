#ifndef OPENGL_H
#define OPENGL_H

#define USE_GLFW_ENGINE 1

#if USE_GLFW_ENGINE

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#endif

#endif