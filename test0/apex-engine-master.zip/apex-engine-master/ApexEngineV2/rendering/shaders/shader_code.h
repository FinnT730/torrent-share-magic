#ifndef SHADER_CODE_H
#define SHADER_CODE_H

namespace apex {

class ShaderCode {
public:
    static const char *aabb_debug_vs;
    static const char *aabb_debug_fs;
};

} // namespace apex

#endif