#include "renderable.h"

namespace apex {

Renderable::Renderable(RenderBucket bucket)
    : m_bucket(bucket)
{
}

} // namespace apex