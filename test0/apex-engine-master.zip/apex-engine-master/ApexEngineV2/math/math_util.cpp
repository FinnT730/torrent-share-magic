#include "math_util.h"

namespace apex {

const double MathUtil::PI = 3.14159265358979;
const double MathUtil::EPSILON = 0.0001;

} // namespace apex